
module.exports = {
  token: "MTI1OTYwOTM5MjE0MDEyODM2MA.G6BxTq.5cPvVeaGW9n_K1SPPVF8CPRMi8bn3zi0RvFbA8",
  prefix: "!",
  owner: "869944197472456794"
}; 
